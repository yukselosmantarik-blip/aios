/**
 * GENERATED LEGAL PAGE — Impressum
 * Route: /impressum
 */

import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: "Impressum | Müller Gebäudeservice",
  description: "Impressum und Anbieterkennzeichnung von Müller Gebäudeservice.",
  robots: 'index,follow',
  alternates: {
    canonical: "/impressum",
  },
};

export default function ImpressumPage() {
  return (
    <article className="pg-page">
      <section className="pg-legal-page" aria-labelledby="legal-page-heading">
        <h1 id="legal-page-heading">Impressum</h1>
        <p>Angaben gemäß § 5 TMG</p>
        <p>Müller Gebäudeservice</p>
        <p>Fischergasse 12</p>
        <p>89073 Ulm</p>
        <p>Telefon: 0731 555 42 18</p>
        <p>E-Mail: kontakt@mueller-gebaeudeservice.de</p>
        <p>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV: Müller Gebäudeservice</p>
        <p className="pg-legal-page__actions">
          <Link href="/" className="landing-link-button">
            Zur Startseite
          </Link>
        </p>
      </section>
    </article>
  );
}
