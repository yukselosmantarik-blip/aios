/**
 * GENERATED ROOT LAYOUT — Sprint 8.2C
 */

import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import '@/styles/globals.css';
import { SiteFooter, SiteHeader } from '@/components/generated';
import { MobileStickyCTA } from '@/components/generated';
import { variants } from '@/styles/tailwind-mapping';

export const metadata: Metadata = {
  title: { default: "Müller Gebäudeservice", template: "{page} | {businessName}" },
  description: "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
  metadataBase: undefined,
  robots: "index,follow",
  openGraph: {
    title: "Müller Gebäudeservice",
    description: "Neukunden gewinnen und Vertrauen für zuverlässige Gebäudereinigung schaffen",
    type: 'website',
  },
};

type RootLayoutProps = {
  children: ReactNode;
};

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="de">
      <body className={variants.bodyRoot}>
        <a href="#main-content" className={variants.skipLink}>Zum Inhalt springen</a>
        <SiteHeader />
        <main id="main-content">{children}</main>
        <SiteFooter />
        <MobileStickyCTA />
      </body>
    </html>
  );
}
