/**
 * GENERATED PAGE — Home
 * Route: /
 * Sprint 8.2B/8.2C — page-level React
 */

import type { Metadata } from 'next';
import { page_homeConfig } from '@/content/pages/page-home';
import {
  ContactSection,
  ContentSection,
  FAQSection,
  FeatureGridSection,
  HeroSection,
  TestimonialSection,
} from '@/components/generated';

export const metadata: Metadata = {
  title: "Startseite | Müller Gebäudeservice",
  description: "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
  robots: "index,follow",
  openGraph: {
    title: "Müller Gebäudeservice — Startseite",
    description: "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Müller Gebäudeservice — Startseite",
    description: "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
  },
  alternates: {
    canonical: "/",
  },
};

// selected patterns: hero, navbar, footer, statistics, feature-grid, usp-block, testimonials, gallery, location, faq, cta-banner

export default function HomePage() {
  return (
    <article className="pg-page">
      {/* H1 direction: Müller Gebäudeservice */}

      <HeroSection
        section={page_homeConfig.sections[0]}
      />
      <ContentSection
        section={page_homeConfig.sections[1]}
      />
      <FeatureGridSection
        section={page_homeConfig.sections[2]}
      />
      <FeatureGridSection
        section={page_homeConfig.sections[3]}
      />
      <TestimonialSection
        section={page_homeConfig.sections[4]}
      />
      <FAQSection
        section={page_homeConfig.sections[5]}
      />
      <ContactSection
        section={page_homeConfig.sections[6]}
      />
    </article>
  );
}
