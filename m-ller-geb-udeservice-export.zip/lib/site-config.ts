/**
 * GENERATED PROJECT SHELL — Sprint 8.2A
 * Compiled site configuration export
 * React implementation is intentionally deferred.
 */

export const siteConfig = {
  "metadata": {
    "projectId": "project:muller-gebaudeservice",
    "projectName": "Müller Gebäudeservice",
    "generatedAt": "1970-01-01T00:00:00.000Z",
    "compilerVersion": "8.1.0",
    "sourceBlueprintId": "sample-blueprint-mueller-business",
    "sourceBriefId": "b8e2c4a1-9f3d-4e2a-b1c0-8d7e6f5a4b3c",
    "generationMode": "deterministic",
    "targetFramework": "nextjs",
    "language": "de",
    "locale": "de-DE",
    "status": "compiled"
  },
  "business": {
    "businessName": "Müller Gebäudeservice",
    "industry": "Lokaler Gebäudeservice und Facility Pflege",
    "location": "Ulm",
    "websiteGoal": "Neukunden gewinnen und Vertrauen für zuverlässige Gebäudereinigung schaffen",
    "targetAudience": "Hausverwaltungen, Praxen und Gewerbetreibende in Ulm",
    "usp": "Feste Teams, flexible Zeiten, transparente Leistungsnachweise",
    "services": [
      "Unterhaltsreinigung",
      "Treppenhausreinigung",
      "Glasreinigung",
      "Sonderreinigung"
    ],
    "profile": "business"
  },
  "site": {
    "sitemap": [
      "Home"
    ],
    "primaryCta": "Anfrage senden",
    "secondaryCta": "Ulm entdecken",
    "styleTier": "modern",
    "prefersMotion": false,
    "referenceWebsites": []
  },
  "locale": {
    "primaryLanguage": "de",
    "formalAddress": "Sie",
    "numberFormat": "de-DE",
    "dateFormat": "DD.MM.YYYY",
    "timeFormat": "24h",
    "currencyPlaceholder": "[PLACEHOLDER: EUR]"
  },
  "theme": {
    "mode": "light",
    "primaryColor": "#0F766E",
    "secondaryColor": "#0369A1",
    "styleDescription": "Modern, klar, vertrauenswürdig"
  },
  "navigation": {
    "desktopNavigation": [
      {
        "id": "nav-item:home",
        "label": "Home",
        "routeId": "route:home",
        "routePath": "/",
        "order": 1
      }
    ],
    "mobileNavigation": [
      {
        "id": "nav-item:home",
        "label": "Home",
        "routeId": "route:home",
        "routePath": "/",
        "order": 1
      }
    ],
    "primaryNavigationItems": [
      {
        "id": "nav-item:home",
        "label": "Home",
        "routeId": "route:home",
        "routePath": "/",
        "order": 1
      }
    ],
    "ctaItem": {
      "id": "nav-item:primary-cta",
      "label": "Anfrage senden",
      "routeId": "route:home",
      "routePath": "/",
      "order": 2
    },
    "activeStateBehavior": "Underline or color token active state on current route",
    "focusBehavior": "Visible focus ring on all nav links",
    "mobileOpenCloseBehavior": "Drawer with aria-expanded toggle",
    "stickyBehavior": "Sticky header after scroll",
    "scrollBehavior": "Optional shrink on scroll; no scroll-jacking"
  },
  "footer": {
    "variant": "standard",
    "navigationGroups": [
      {
        "title": "Seiten",
        "items": [
          {
            "id": "footer-item:home",
            "label": "Home",
            "routeId": "route:home",
            "routePath": "/",
            "order": 1
          }
        ]
      }
    ],
    "contactPlaceholders": [],
    "legalPlaceholders": [],
    "socialPlaceholders": [],
    "ctaArea": {
      "label": "Anfrage senden",
      "routeId": "route:home"
    },
    "mobileStackingOrder": [
      "brand",
      "navigation",
      "contact",
      "legal",
      "social"
    ],
    "accessibilityRequirements": [
      "Footer landmark",
      "Link lists as ul",
      "Legal links text labels"
    ]
  },
  "featureFlags": [
    {
      "name": "onlineOrdering",
      "enabled": false,
      "source": "brief.goal/features",
      "requiredInputs": [
        "order endpoint"
      ],
      "missingInputs": [],
      "implementationStatus": "blocked"
    },
    {
      "name": "reservation",
      "enabled": false,
      "source": "brief.goal/features",
      "requiredInputs": [
        "booking provider"
      ],
      "missingInputs": [],
      "implementationStatus": "blocked"
    },
    {
      "name": "contactForm",
      "enabled": true,
      "source": "brief.features",
      "requiredInputs": [
        "form destination email"
      ],
      "missingInputs": [],
      "implementationStatus": "ready"
    },
    {
      "name": "maps",
      "enabled": false,
      "source": "brief.features",
      "requiredInputs": [
        "address",
        "maps URL"
      ],
      "missingInputs": [
        "maps URL"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "instagram",
      "enabled": true,
      "source": "brief.features/notes",
      "requiredInputs": [
        "instagram URL"
      ],
      "missingInputs": [
        "instagram URL"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "clickToCall",
      "enabled": false,
      "source": "brief.notes",
      "requiredInputs": [
        "phone"
      ],
      "missingInputs": [
        "phone"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "openingHours",
      "enabled": false,
      "source": "brief.notes",
      "requiredInputs": [
        "opening hours"
      ],
      "missingInputs": [
        "opening hours"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "gallery",
      "enabled": false,
      "source": "brief.features",
      "requiredInputs": [
        "gallery images"
      ],
      "missingInputs": [
        "gallery images"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "animations",
      "enabled": false,
      "source": "brief.style",
      "requiredInputs": [],
      "missingInputs": [],
      "implementationStatus": "blocked"
    },
    {
      "name": "analytics",
      "enabled": false,
      "source": "brief.features",
      "requiredInputs": [
        "analytics config"
      ],
      "missingInputs": [
        "analytics config"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "cms",
      "enabled": false,
      "source": "default v1",
      "requiredInputs": [
        "cms selection"
      ],
      "missingInputs": [
        "cms selection"
      ],
      "implementationStatus": "placeholder"
    },
    {
      "name": "newsletter",
      "enabled": false,
      "source": "brief.features",
      "requiredInputs": [
        "newsletter provider"
      ],
      "missingInputs": [],
      "implementationStatus": "blocked"
    },
    {
      "name": "multilingual",
      "enabled": false,
      "source": "brief.notes",
      "requiredInputs": [
        "translation set"
      ],
      "missingInputs": [],
      "implementationStatus": "blocked"
    },
    {
      "name": "darkMode",
      "enabled": false,
      "source": "brief.notes",
      "requiredInputs": [
        "theme decision"
      ],
      "missingInputs": [],
      "implementationStatus": "blocked"
    }
  ],
  "missingData": [
    {
      "id": "missing:phone",
      "category": "contact",
      "field": "phone",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "ContactForm"
      ],
      "severity": "medium",
      "placeholder": "[PLACEHOLDER: phone]",
      "recommendation": "Add phone to brief notes",
      "blocksGeneration": false,
      "blocksLaunch": false
    },
    {
      "id": "missing:email",
      "category": "contact",
      "field": "email",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "ContactForm"
      ],
      "severity": "medium",
      "placeholder": "[PLACEHOLDER: email]",
      "recommendation": "Add email to brief notes",
      "blocksGeneration": false,
      "blocksLaunch": false
    },
    {
      "id": "missing:opening-hours",
      "category": "operations",
      "field": "opening hours",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "OpeningHours"
      ],
      "severity": "medium",
      "placeholder": "[PLACEHOLDER: opening hours]",
      "recommendation": "Provide weekly hours",
      "blocksGeneration": false,
      "blocksLaunch": false
    },
    {
      "id": "missing:product-images",
      "category": "media",
      "field": "product images",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "Gallery",
        "ProductCard"
      ],
      "severity": "high",
      "placeholder": "[PLACEHOLDER: product images]",
      "recommendation": "Upload photography",
      "blocksGeneration": false,
      "blocksLaunch": false
    },
    {
      "id": "missing:testimonials",
      "category": "trust",
      "field": "testimonials",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "Testimonial"
      ],
      "severity": "medium",
      "placeholder": "[PLACEHOLDER: testimonials]",
      "recommendation": "Collect verified testimonials",
      "blocksGeneration": false,
      "blocksLaunch": false
    },
    {
      "id": "missing:legal-text",
      "category": "legal",
      "field": "legal text",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "SiteFooter"
      ],
      "severity": "high",
      "placeholder": "[PLACEHOLDER: Impressum & Datenschutz]",
      "recommendation": "Supply legal copy",
      "blocksGeneration": false,
      "blocksLaunch": true
    },
    {
      "id": "missing:domain",
      "category": "launch",
      "field": "domain",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [],
      "severity": "medium",
      "placeholder": "[PLACEHOLDER: production domain]",
      "recommendation": "Confirm production domain",
      "blocksGeneration": false,
      "blocksLaunch": true
    },
    {
      "id": "missing:product-prices",
      "category": "commerce",
      "field": "product prices",
      "affectedPages": [
        "page:home"
      ],
      "affectedComponents": [
        "ProductCard"
      ],
      "severity": "medium",
      "placeholder": "[PLACEHOLDER: EUR prices]",
      "recommendation": "Confirm whether prices should be shown",
      "blocksGeneration": false,
      "blocksLaunch": false
    }
  ]
} as const;

export type siteConfig = typeof siteConfig;
