/**
 * GENERATED PAGE CONFIG — Sprint 8.2B
 * Page: Home
 */

export const page_homeConfig = {
  "pageId": "page:home",
  "pageName": "Home",
  "pageRole": "home",
  "title": "Startseite | Müller Gebäudeservice",
  "description": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
  "route": "/",
  "h1Direction": "Müller Gebäudeservice",
  "primaryCta": "Anfrage senden",
  "secondaryCta": "Ulm entdecken",
  "selectedPatternIds": [
    "hero",
    "navbar",
    "footer",
    "statistics",
    "feature-grid",
    "usp-block",
    "testimonials",
    "gallery",
    "location",
    "faq",
    "cta-banner"
  ],
  "sections": [
    {
      "missingData": [],
      "contentBlocks": [],
      "media": [],
      "ctaReferences": [
        "mailto:kontakt@mueller-gebaeudeservice.de",
        "#services"
      ],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "home",
      "title": "Müller Gebäudeservice",
      "name": "HeroSection",
      "eyebrow": "Sauberkeit und Werterhalt für Wohn- und Gewerbeimmobilien in Ulm",
      "description": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. Unser Team arbeitet termintreu, dokumentiert Leistungen transparent und ist bei Bedarf kurzfristig erreichbar.",
      "type": "hero",
      "order": 1,
      "priority": 100,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Drive Hausverwaltungen, Praxen und Gewerbetreibende in Ulm toward Neukunden gewinnen und Vertrauen für zuverlässige Gebäudereinigung schaffen. Prioritize services clarity and contact path.",
      "componentName": "HeroSection",
      "primaryCTA": "Beratung anfragen",
      "secondaryCTA": "Leistungen ansehen",
      "headingLevel": 1,
      "sourcePatternIds": [
        "hero"
      ],
      "contentBody": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. Unser Team arbeitet termintreu, dokumentiert Leistungen transparent und ist bei Bedarf kurzfristig erreichbar.",
      "contentLines": [
        "Sauberkeit und Werterhalt für Wohn- und Gewerbeimmobilien in Ulm"
      ],
      "primaryCtaHref": "mailto:kontakt@mueller-gebaeudeservice.de",
      "secondaryCtaHref": "#services",
      "heroLayout": "legacy",
      "tagline": "Sauberkeit und Werterhalt für Wohn- und Gewerbeimmobilien in Ulm",
      "phone": "0731 555 42 18",
      "address": "Fischergasse 12, 89073 Ulm"
    },
    {
      "missingData": [],
      "contentBlocks": [
        "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen.",
        "Unser Team arbeitet termintreu, dokumentiert Leistungen transparent und ist bei Bedarf kurzfristig erreichbar."
      ],
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "about",
      "title": "Über uns",
      "name": "ContentSection",
      "eyebrow": "Müller Gebäudeservice",
      "description": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. Unser Team arbeitet termintreu, dokumentiert Leistungen transparent und ist bei Bedarf kurzfristig erreichbar.",
      "type": "content",
      "order": 2,
      "priority": 80,
      "hierarchyLevel": "primary",
      "visualWeight": "high",
      "purpose": "Introduce the company",
      "componentName": "ContentSection",
      "primaryCTA": null,
      "secondaryCTA": null,
      "headingLevel": 2,
      "sourcePatternIds": [
        "feature-grid"
      ],
      "contentBody": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. Unser Team arbeitet termintreu, dokumentiert Leistungen transparent und ist bei Bedarf kurzfristig erreichbar.",
      "contentLines": [
        "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen",
        "Unser Team arbeitet termintreu, dokumentiert Leistungen transparent und ist bei Bedarf kurzfristig erreichbar."
      ]
    },
    {
      "missingData": [],
      "contentBlocks": [
        "Unterhaltsreinigung: Regelmäßige Reinigung von Büros, Praxen und Gemeinschaftsflächen nach abgestimmtem Plan.",
        "Treppenhausreinigung: Pflege von Treppenhäusern, Eingangsbereichen und Glasflächen in Mehrfamilienhäusern.",
        "Glas- und Fensterreinigung: Streifenfreie Fenster- und Glasfassadenreinigung für Innen- und Außenbereiche.",
        "Sonder- und Grundreinigung: Grundreinigungen nach Renovierungen, Umzügen oder vor Objektübergaben."
      ],
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "services",
      "title": "Leistungen",
      "name": "FeatureGridSection",
      "eyebrow": "Services",
      "description": "Unsere Leistungen im Überblick",
      "type": "feature-grid",
      "order": 3,
      "priority": 85,
      "hierarchyLevel": "primary",
      "visualWeight": "high",
      "purpose": "Present service offerings",
      "componentName": "FeatureGridSection",
      "primaryCTA": "Beratung anfragen",
      "secondaryCTA": null,
      "headingLevel": 2,
      "sourcePatternIds": [
        "feature-grid"
      ],
      "contentBody": "Unterhaltsreinigung | Treppenhausreinigung | Glas- und Fensterreinigung | Sonder- und Grundreinigung",
      "contentLines": [
        "Unterhaltsreinigung",
        "Treppenhausreinigung",
        "Glas- und Fensterreinigung",
        "Sonder- und Grundreinigung"
      ]
    },
    {
      "missingData": [],
      "contentBlocks": [
        "Feste Ansprechpartner: Sie kennen unser Team vor Ort und erreichen uns direkt ohne Callcenter.",
        "Flexible Einsatzzeiten: Reinigung außerhalb Ihrer Geschäftszeiten oder in abgestimmten Zeitfenstern.",
        "Nachvollziehbare Leistungen: Leistungsnachweise und transparente Abrechnung für Hausverwaltungen und Eigentümer."
      ],
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "benefits",
      "title": "Ihre Vorteile",
      "name": "FeatureGridSection",
      "eyebrow": "Benefits",
      "description": "Warum Kunden uns wählen",
      "type": "feature-grid",
      "order": 4,
      "priority": 75,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Highlight benefits",
      "componentName": "FeatureGridSection",
      "primaryCTA": null,
      "secondaryCTA": null,
      "headingLevel": 2,
      "sourcePatternIds": [
        "feature-grid"
      ],
      "contentBody": "Feste Ansprechpartner | Flexible Einsatzzeiten | Nachvollziehbare Leistungen",
      "contentLines": [
        "Feste Ansprechpartner",
        "Flexible Einsatzzeiten",
        "Nachvollziehbare Leistungen"
      ]
    },
    {
      "missingData": [],
      "contentBlocks": [
        "Seit dem Wechsel zu Müller Gebäudeservice ist unser Treppenhaus dauerhaft gepflegt. Termine werden eingehalten und Rückmeldungen sind schnell da. — Sabine Keller, Hausverwaltung Keller & Partner, Ulm",
        "Für unsere Praxisräume war uns eine verlässliche Abendreinigung wichtig. Das Team arbeitet diskret und gründlich. — Dr. Jonas Hartmann, Praxis Hartmann, Blaubeuren"
      ],
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "testimonials",
      "title": "Kundenstimmen",
      "name": "TestimonialSection",
      "eyebrow": "Testimonials",
      "description": "Was unsere Kunden sagen",
      "type": "testimonials",
      "order": 5,
      "priority": 70,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Social proof",
      "componentName": "TestimonialSection",
      "primaryCTA": null,
      "secondaryCTA": null,
      "headingLevel": 2,
      "sourcePatternIds": [
        "testimonials"
      ],
      "contentBody": "Seit dem Wechsel zu Müller Gebäudeservice ist unser Treppenhaus dauerhaft gepflegt. Termine werden eingehalten und Rückmeldungen sind schnell da. | Für unsere Praxisräume war uns eine verlässliche Abendreinigung wichtig. Das Team arbeitet diskret und gründlich.",
      "contentLines": [
        "Seit dem Wechsel zu Müller Gebäudeservice ist unser Treppenhaus dauerhaft gepflegt. Termine werden eingehalten und Rückmeldungen sind schnell da.",
        "Für unsere Praxisräume war uns eine verlässliche Abendreinigung wichtig. Das Team arbeitet diskret und gründlich."
      ]
    },
    {
      "missingData": [],
      "contentBlocks": [],
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [
        {
          "id": "faq-1",
          "question": "Erstellen Sie individuelle Reinigungspläne?",
          "answer": "Ja. Nach einer Besichtigung definieren wir Leistungen, Intervalle und Prioritäten gemeinsam mit Ihnen."
        },
        {
          "id": "faq-2",
          "question": "Arbeiten Sie auch kurzfristig?",
          "answer": "Für Bestandskunden halten wir Kapazitäten für Sonderreinigungen vor. Sprechen Sie uns frühzeitig an."
        },
        {
          "id": "faq-3",
          "question": "In welchem Gebiet sind Sie tätig?",
          "answer": "Unser Schwerpunkt liegt in Ulm, Neu-Ulm und im Alb-Donau-Kreis."
        }
      ],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "faq",
      "title": "Häufige Fragen",
      "name": "FAQSection",
      "eyebrow": "FAQ",
      "description": "Antworten auf häufige Fragen",
      "type": "faq",
      "order": 6,
      "priority": 65,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Answer common questions",
      "componentName": "FAQSection",
      "primaryCTA": null,
      "secondaryCTA": null,
      "headingLevel": 2,
      "sourcePatternIds": [
        "faq"
      ],
      "contentBody": "Erstellen Sie individuelle Reinigungspläne? | Arbeiten Sie auch kurzfristig? | In welchem Gebiet sind Sie tätig?",
      "contentLines": [
        "Erstellen Sie individuelle Reinigungspläne?",
        "Arbeiten Sie auch kurzfristig?",
        "In welchem Gebiet sind Sie tätig?"
      ]
    },
    {
      "missingData": [],
      "contentBlocks": [],
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "menuItems": [],
      "faqItems": [],
      "trustBadges": [],
      "isPlaceholder": false,
      "id": "contact",
      "title": "Kontakt",
      "name": "ContactSection",
      "eyebrow": "Kontakt",
      "description": "Fischergasse 12, 89073 Ulm",
      "type": "contact",
      "order": 7,
      "priority": 90,
      "hierarchyLevel": "primary",
      "visualWeight": "high",
      "purpose": "Enable contact",
      "componentName": "ContactSection",
      "primaryCTA": "Beratung anfragen",
      "secondaryCTA": "0731 555 42 18",
      "headingLevel": 2,
      "sourcePatternIds": [
        "feature-grid"
      ],
      "contentBody": "Fischergasse 12, 89073 Ulm | 0731 555 42 18 | kontakt@mueller-gebaeudeservice.de",
      "contentLines": [
        "Fischergasse 12, 89073 Ulm",
        "0731 555 42 18",
        "kontakt@mueller-gebaeudeservice.de"
      ],
      "phone": "0731 555 42 18",
      "address": "Fischergasse 12, 89073 Ulm",
      "primaryCtaHref": "mailto:kontakt@mueller-gebaeudeservice.de"
    }
  ],
  "ctas": {
    "primary": "Anfrage senden",
    "secondary": "Ulm entdecken"
  },
  "mediaPlaceholders": [
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]"
  ],
  "seo": {
    "title": "Startseite | Müller Gebäudeservice",
    "titlePattern": "{page} | {businessName}",
    "metaDescription": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
    "canonical": "/",
    "robots": "index,follow",
    "openGraph": {
      "title": "Müller Gebäudeservice — Startseite",
      "description": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. ",
      "type": "website"
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "Müller Gebäudeservice — Startseite",
      "description": "Müller Gebäudeservice unterstützt Eigentümer, Verwaltungen und Gewerbetreibende mit zuverlässiger Unterhaltsreinigung, Treppenhauspflege und Sonderreinigungen. "
    },
    "primaryKeyword": "Unterhaltsreinigung",
    "supportingKeywords": [
      "Unterhaltsreinigung",
      "Treppenhausreinigung",
      "Glasreinigung",
      "Sonderreinigung",
      "Lokaler Gebäudeservice und Facility Pflege"
    ],
    "h1Direction": "Müller Gebäudeservice",
    "structuredDataType": "Organization",
    "breadcrumbRecommendation": [
      "Home",
      "Home"
    ],
    "internalLinks": [],
    "missingSeoInputs": []
  },
  "missingDataReferences": [
    "phone",
    "email",
    "opening hours",
    "product images",
    "testimonials",
    "legal text",
    "domain",
    "product prices"
  ],
  "internalLinks": [],
  "implementationWarnings": []
} as const;

export type page_homeConfigType = typeof page_homeConfig;
