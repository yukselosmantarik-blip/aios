/**
 * GENERATED PROJECT SHELL — Sprint 8.2A
 * Shared site type metadata
 * React implementation is intentionally deferred.
 */

export const siteTypesMetadata = {
  "routes": [
    {
      "id": "route:home",
      "routePath": "/",
      "pageRole": "home"
    }
  ],
  "pages": [
    {
      "id": "page:home",
      "pageName": "Home",
      "routeId": "route:home"
    }
  ]
} as const;

export type siteTypes = typeof siteTypesMetadata;
