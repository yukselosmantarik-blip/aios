/**
 * GENERATED COMPONENT REGISTRY — Sprint 8.3
 * Stable export order for page and layout imports.
 */

export type {
  CardVariant,
  CTA,
  ContentBlockModel,
  ContactDetailsModel,
  FAQItem,
  MediaPlaceholderModel,
  MissingDataReference,
  NavigationItemModel,
  OpeningHoursPlaceholder,
  PlaceholderCategory,
  ProductMenuItemPlaceholder,
  SectionBaseProps,
  SectionComponentProps,
  TestimonialPlaceholder,
} from './types';

export { SiteHeader } from './SiteHeader';
export { SiteFooter } from './SiteFooter';
export { HeroSection } from './HeroSection';
export { FeatureGridSection } from './FeatureGridSection';
export { TestimonialSection } from './TestimonialSection';
export { FAQSection } from './FAQSection';
export { ContactSection } from './ContactSection';
export { ContactForm } from './ContactForm';
export { ContentSection } from './ContentSection';
export { GenericSection } from './GenericSection';
export { MobileStickyCTA } from './MobileStickyCTA';
export { SectionHeading } from './SectionHeading';
export { ButtonLink } from './ButtonLink';
export { MediaPlaceholder } from './MediaPlaceholder';
