/**
 * GENERATED COMPONENT — FeatureGridSection
 * Sprint 8.3 — premium visual component library
 */


import type { SectionComponentProps } from './types';
import { SectionHeading } from './SectionHeading';
import { SectionShell } from './SectionShell';
import { Container } from './Container';
import { Stack } from './Stack';
import { cn, variants } from '@/styles/tailwind-mapping';
import { Card } from './Card';
import { ResponsiveGrid } from './ResponsiveGrid';

export function FeatureGridSection({ section }: SectionComponentProps) {
  return (
    <SectionShell id={section.id} headingId={`${section.id}-heading`} className={section.className}>
      <Container>
        <Stack gap="lg">
          <SectionHeading section={section} />
          {(() => {
            const items = section.contentBlocks.length > 0 ? section.contentBlocks : (section.contentLines ?? []);
            if (items.length === 0) {
              return null;
            }
            return (
              <ResponsiveGrid columns={3}>
                {items.map((item) => {
                  const splitAt = item.indexOf(': ');
                  const title = splitAt > 0 ? item.slice(0, splitAt) : item;
                  const description = splitAt > 0 ? item.slice(splitAt + 2) : '';
                  const initial = title.trim().charAt(0).toUpperCase() || '?';
                  return (
                    <li key={item}>
                      <Card variant="interactive" as="article">
                        <Stack gap="sm">
                          <span
                            aria-hidden="true"
                            className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--color-primary)]/10 text-sm font-[var(--font-weight-semibold)] text-[var(--color-primary)]"
                          >
                            {initial}
                          </span>
                          <h3 className="text-base font-[var(--font-weight-medium)]">{title}</h3>
                          {description ? (
                            <p className="text-[length:var(--font-size-sm)] text-[var(--color-text-muted)]">
                              {description}
                            </p>
                          ) : null}
                        </Stack>
                      </Card>
                    </li>
                  );
                })}
              </ResponsiveGrid>
            );
          })()}
        </Stack>
      </Container>
    </SectionShell>
  );
}
