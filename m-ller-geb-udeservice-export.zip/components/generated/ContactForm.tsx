/**
 * GENERATED COMPONENT — ContactForm
 * Sprint 8.3 — premium visual component library
 */

'use client';


import { cn, variants } from '@/styles/tailwind-mapping';
import Link from 'next/link';
import { useState } from 'react';

type FormStatus = 'idle' | 'loading' | 'success' | 'error';

type ContactFormProps = {
  className?: string;
};

export function ContactForm({ className }: ContactFormProps) {
  const [status, setStatus] = useState<FormStatus>('idle');

  return (
    <form
      className={cn('space-y-[var(--spacing-md)]', className)}
      noValidate
      aria-label="Kontaktformular"
      onSubmit={(event) => {
        event.preventDefault();
        setStatus('loading');
        window.setTimeout(() => setStatus('success'), 600);
      }}
    >
      <div>
        <label htmlFor="name" className="block text-sm font-[var(--font-weight-medium)]">Name *</label>
        <input id="name" name="name" type="text" placeholder="Max Mustermann" className={variants.input} required disabled={status === 'loading'} />
      </div>
      <div>
        <label htmlFor="email" className="block text-sm font-[var(--font-weight-medium)]">E-Mail *</label>
        <input id="email" name="email" type="email" placeholder="ihre@email.de" className={variants.input} required disabled={status === 'loading'} />
      </div>
      <div>
        <label htmlFor="message" className="block text-sm font-[var(--font-weight-medium)]">Nachricht *</label>
        <textarea id="message" name="message" placeholder="Wie können wir helfen?" className={variants.input} rows={4} required disabled={status === 'loading'} />
      </div>
      <label className="flex items-start gap-[var(--spacing-sm)] text-sm">
        <input type="checkbox" required disabled={status === 'loading'} />
        <span>
          Ich willige in die Verarbeitung meiner Angaben zur Bearbeitung der Anfrage ein. Details in der{" "}
          <Link href="/datenschutz" className="underline underline-offset-2">
            Datenschutzerklärung
          </Link>
          .
        </span>
      </label>
      {status === 'success' ? (
        <p className="text-sm text-[var(--color-primary)]" role="status">
          Vielen Dank — wir melden uns in der Regel innerhalb eines Werktags.
        </p>
      ) : null}
      <button
        type="submit"
        className={cn(variants.buttonPrimary, variants.motionSafe, 'min-h-11')}
        disabled={status === 'loading'}
        aria-busy={status === 'loading'}
      >
        {status === 'loading' ? 'Wird gesendet …' : 'Anfrage senden'}
      </button>
    </form>
  );
}
