/**
 * GENERATED COMPONENT — TestimonialSection
 * Sprint 8.3 — premium visual component library
 */


import type { SectionComponentProps } from './types';
import { SectionHeading } from './SectionHeading';
import { SectionShell } from './SectionShell';
import { Container } from './Container';
import { Stack } from './Stack';
import { cn, variants } from '@/styles/tailwind-mapping';
import { resolveAsset } from '@/lib/assets/resolve-asset';
import { Card } from './Card';
import { Placeholder } from './Placeholder';

export function TestimonialSection({ section }: SectionComponentProps) {
  return (
    <SectionShell id={section.id} headingId={`${section.id}-heading`} className={section.className}>
      <Container>
        <Stack gap="lg">
          <SectionHeading section={section} />
          <Card variant="testimonial" className="flex flex-col gap-[var(--spacing-md)] sm:flex-row sm:items-start">
            {(() => {
              const avatarAsset = resolveAsset('avatar');
              return (
                <img
                  src={avatarAsset.path}
                  alt={avatarAsset.altText}
                  className="h-16 w-16 shrink-0 rounded-full object-cover"
                  loading="lazy"
                  data-asset-type={avatarAsset.assetType}
                  data-placeholder={String(avatarAsset.placeholder)}
                  data-replace-before-production={String(avatarAsset.replaceBeforeProduction)}
                />
              );
            })()}
            <Placeholder label="[PLACEHOLDER: Testimonial]" category="testimonial" launchBlocking />
          </Card>
        </Stack>
      </Container>
    </SectionShell>
  );
}
