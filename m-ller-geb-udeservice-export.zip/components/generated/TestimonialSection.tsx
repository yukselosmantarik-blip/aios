/**
 * GENERATED COMPONENT — TestimonialSection
 * Sprint 8.3 — premium visual component library
 */


import type { SectionComponentProps } from './types';
import { SectionHeading } from './SectionHeading';
import { SectionShell } from './SectionShell';
import { Container } from './Container';
import { Stack } from './Stack';
import { cn, variants } from '@/styles/tailwind-mapping';
import { Card } from './Card';
import { ResponsiveGrid } from './ResponsiveGrid';

export function TestimonialSection({ section }: SectionComponentProps) {
  return (
    <SectionShell id={section.id} headingId={`${section.id}-heading`} className={section.className}>
      <Container>
        <Stack gap="lg">
          <SectionHeading section={section} />
          {(() => {
            const items = section.contentBlocks.length > 0 ? section.contentBlocks : (section.contentLines ?? []);
            if (items.length === 0) {
              return null;
            }
            return (
              <ResponsiveGrid columns={2}>
                {items.map((block) => {
                  const separator = block.lastIndexOf(' — ');
                  const quote = separator > 0 ? block.slice(0, separator) : block;
                  const attribution = separator > 0 ? block.slice(separator + 3) : '';
                  const comma = attribution.indexOf(', ');
                  const author = comma > 0 ? attribution.slice(0, comma) : attribution;
                  const role = comma > 0 ? attribution.slice(comma + 2) : '';
                  return (
                    <li key={block}>
                      <Card variant="testimonial" className="flex h-full flex-col gap-[var(--spacing-md)]">
                        <p className="text-[length:var(--font-size-md)] leading-relaxed text-[var(--color-text-muted)]">
                          {`„${quote}"`}
                        </p>
                        {(author || role) ? (
                          <footer className="mt-auto text-[length:var(--font-size-sm)]">
                            {author ? (
                              <p className="font-[var(--font-weight-medium)] text-[var(--color-text)]">{author}</p>
                            ) : null}
                            {role ? (
                              <p className="text-[var(--color-text-muted)]">{role}</p>
                            ) : null}
                          </footer>
                        ) : null}
                      </Card>
                    </li>
                  );
                })}
              </ResponsiveGrid>
            );
          })()}
        </Stack>
      </Container>
    </SectionShell>
  );
}
