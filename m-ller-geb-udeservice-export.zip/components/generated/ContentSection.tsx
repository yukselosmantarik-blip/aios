/**
 * GENERATED COMPONENT — ContentSection
 * Sprint 8.3 — premium visual component library
 */


import type { SectionComponentProps } from './types';
import { SectionHeading } from './SectionHeading';
import { SectionShell } from './SectionShell';
import { Container } from './Container';
import { Stack } from './Stack';
import { cn, variants } from '@/styles/tailwind-mapping';
import { ButtonLink } from './ButtonLink';

export function ContentSection({ section }: SectionComponentProps) {
  return (
    <SectionShell id={section.id} headingId={`${section.id}-heading`} className={section.className}>
      <Container>
        <Stack gap="lg">
          <SectionHeading section={section} />
          {(() => {
            const paragraphs =
              section.contentBlocks.length > 0 ? section.contentBlocks : (section.contentLines ?? []);
            if (paragraphs.length === 0) {
              return section.description ? (
                <p className="max-w-3xl text-[length:var(--font-size-md)] leading-relaxed text-[var(--color-text-muted)]">
                  {section.description}
                </p>
              ) : null;
            }
            return (
              <Stack gap="md" className="max-w-3xl">
                {paragraphs.map((block) => (
                  <p key={block} className="text-[length:var(--font-size-md)] leading-relaxed text-[var(--color-text-muted)]">
                    {block}
                  </p>
                ))}
              </Stack>
            );
          })()}
          {section.primaryCTA && section.primaryCtaHref ? (
            <ButtonLink cta={{ label: section.primaryCTA, href: section.primaryCtaHref, variant: 'primary' }} />
          ) : null}
        </Stack>
      </Container>
    </SectionShell>
  );
}
