/**
 * GENERATED COMPONENT — ContactSection
 * Sprint 8.3 — premium visual component library
 */

import type { SectionComponentProps } from './types';
import { SectionHeading } from './SectionHeading';
import { SectionShell } from './SectionShell';
import { Container } from './Container';
import { Stack } from './Stack';
import { cn, variants } from '@/styles/tailwind-mapping';
import { ButtonLink } from './ButtonLink';
import { ContactForm } from './ContactForm';

const businessProfile = {
  "address": "Fischergasse 12, 89073 Ulm",
  "addressLines": [
    "Fischergasse 12",
    "89073 Ulm"
  ],
  "phone": "0731 555 42 18",
  "phoneTelHref": "tel:+497315554218",
  "email": "kontakt@mueller-gebaeudeservice.de",
  "emailMailtoHref": "mailto:kontakt@mueller-gebaeudeservice.de",
  "openingHours": [
    {
      "days": "Montag – Freitag",
      "hours": "07:00 – 18:00 Uhr"
    },
    {
      "days": "Samstag",
      "hours": "08:00 – 12:00 Uhr ( nach Vereinbarung )"
    },
    {
      "days": "Sonntag",
      "hours": "Geschlossen"
    }
  ],
  "socialLinks": [
    {
      "label": "Instagram",
      "href": "https://instagram.com/"
    },
    {
      "label": "LinkedIn",
      "href": "https://linkedin.com/"
    }
  ],
  "legalLinks": [
    {
      "label": "Impressum",
      "href": "/impressum"
    },
    {
      "label": "Datenschutz",
      "href": "/datenschutz"
    }
  ]
};

export function ContactSection({ section }: SectionComponentProps) {
  const telHref = businessProfile.phoneTelHref;
  const mapsQuery = encodeURIComponent(businessProfile.address);
  const primaryHref = section.primaryCtaHref ?? businessProfile.emailMailtoHref ?? '/#contact';

  return (
    <SectionShell id={section.id} headingId={`${section.id}-heading`} className="landing-business-section">
      <Container>
        <div className="grid gap-[var(--spacing-lg)] md:grid-cols-2 md:items-start">
          <Stack gap="md">
            <SectionHeading section={section} />
            {section.description ? (
              <p className="landing-section-lead">{section.description}</p>
            ) : null}
            <dl className="landing-business-details">
              <div className="landing-business-row">
                <dt>Adresse</dt>
                <dd>
                  <a
                    className="landing-business-link"
                    href={`https://www.google.com/maps/search/?api=1&query=${mapsQuery}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {businessProfile.addressLines.map((line) => (
                      <span key={line} className="block">
                        {line}
                      </span>
                    ))}
                  </a>
                </dd>
              </div>
              <div className="landing-business-row">
                <dt>Telefon</dt>
                <dd>
                  <a className="landing-business-link" href={telHref}>
                    {businessProfile.phone}
                  </a>
                </dd>
              </div>
              {businessProfile.email && businessProfile.emailMailtoHref ? (
                <div className="landing-business-row">
                  <dt>E-Mail</dt>
                  <dd>
                    <a className="landing-business-link" href={businessProfile.emailMailtoHref}>
                      {businessProfile.email}
                    </a>
                  </dd>
                </div>
              ) : null}
              <div className="landing-business-row">
                <dt>Öffnungszeiten</dt>
                <dd>
                  <ul className="landing-hours-list">
                    {businessProfile.openingHours.map((entry) => (
                      <li key={`${entry.days}-${entry.hours}`}>
                        <span>{entry.days}</span>
                        <span>{entry.hours}</span>
                      </li>
                    ))}
                  </ul>
                </dd>
              </div>
            </dl>
            {section.primaryCTA ? (
              <ButtonLink cta={{ label: section.primaryCTA, href: primaryHref, variant: 'primary' }} />
            ) : null}
          </Stack>
          <ContactForm />
        </div>
      </Container>
    </SectionShell>
  );
}
