/**
 * GENERATED PAGE — Galerie
 * Route: /gallery
 * Sprint 8.2B/8.2C — page-level React
 */

import type { Metadata } from 'next';
import { page_galerieConfig } from '@/content/pages/page-galerie';
import {
  FeatureGridSection,
  GallerySection,
  HeroSection,
} from '@/components/generated';

export const metadata: Metadata = {
  // missing SEO inputs: location
  title: "Galerie | by Nanis`s Smashburger",
  description: "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  robots: "index,follow",
  openGraph: {
    title: "by Nanis`s Smashburger — Galerie",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "by Nanis`s Smashburger — Galerie",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
  },
  alternates: {
    canonical: "/gallery",
  },
};

// selected patterns: hero, navbar, footer, feature-grid, gallery, cta-banner

export default function GaleriePage() {
  return (
    <article className="pg-page">
      {/* page objective rendered via sections for Galerie */}
      <nav aria-label="Interne Links">
        <ul>
          <li><a href="/">Startseite</a></li>
          <li><a href="/menu">Speisekarte</a></li>
          <li><a href="/about">Über uns</a></li>
          <li><a href="/contact">Kontakt</a></li>
        </ul>
      </nav>
      <HeroSection
        section={page_galerieConfig.sections[0]}
      />
      <FeatureGridSection
        section={page_galerieConfig.sections[1]}
      />
      <GallerySection
        section={page_galerieConfig.sections[2]}
      />
      <GallerySection
        section={page_galerieConfig.sections[3]}
      />
      <GallerySection
        section={page_galerieConfig.sections[4]}
      />
      <GallerySection
        section={page_galerieConfig.sections[5]}
      />
      <GallerySection
        section={page_galerieConfig.sections[6]}
      />
    </article>
  );
}
