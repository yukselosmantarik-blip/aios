/**
 * GENERATED PAGE — Über uns
 * Route: /about
 * Sprint 8.2B/8.2C — page-level React
 */

import type { Metadata } from 'next';
import { page_uber_unsConfig } from '@/content/pages/page-uber-uns';
import {
  CTASection,
  ContentSection,
  FeatureGridSection,
  GenericSection,
  HeroSection,
  TrustSection,
} from '@/components/generated';

export const metadata: Metadata = {
  // missing SEO inputs: location
  title: "Über uns | by Nanis`s Smashburger",
  description: "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  robots: "index,follow",
  openGraph: {
    title: "by Nanis`s Smashburger — Über uns",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "by Nanis`s Smashburger — Über uns",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
  },
  alternates: {
    canonical: "/about",
  },
};

// selected patterns: hero, navbar, footer, timeline, feature-grid, usp-block, team, statistics, cta-banner

export default function BerUnsPage() {
  return (
    <article className="pg-page">
      {/* page objective rendered via sections for Über uns */}
      <nav aria-label="Interne Links">
        <ul>
          <li><a href="/">Startseite</a></li>
          <li><a href="/menu">Speisekarte</a></li>
          <li><a href="/gallery">Galerie</a></li>
          <li><a href="/contact">Kontakt</a></li>
        </ul>
      </nav>
      <HeroSection
        section={page_uber_unsConfig.sections[0]}
      />
      <ContentSection
        section={page_uber_unsConfig.sections[1]}
      />
      <FeatureGridSection
        section={page_uber_unsConfig.sections[2]}
      />
      <TrustSection
        section={page_uber_unsConfig.sections[3]}
      />
      <GenericSection
        section={page_uber_unsConfig.sections[4]}
      />
      <TrustSection
        section={page_uber_unsConfig.sections[5]}
      />
      <CTASection
        section={page_uber_unsConfig.sections[6]}
      />
    </article>
  );
}
