/**
 * GENERATED PAGE — Startseite
 * Route: /
 * Sprint 8.2B/8.2C — page-level React
 */

import type { Metadata } from 'next';
import { page_startseiteConfig } from '@/content/pages/page-startseite';
import {
  CTASection,
  ContactSection,
  FAQSection,
  GallerySection,
  HeroSection,
  MenuSection,
  TestimonialSection,
  TrustSection,
} from '@/components/generated';

export const metadata: Metadata = {
  // missing SEO inputs: location
  title: "Startseite | by Nanis`s Smashburger",
  description: "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  robots: "index,follow",
  openGraph: {
    title: "by Nanis`s Smashburger — Startseite",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "by Nanis`s Smashburger — Startseite",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
  },
  alternates: {
    canonical: "/",
  },
};

// warning: high: Too many high-emphasis sections marked dominant.
// selected patterns: hero, navbar, footer, statistics, menu-grid, usp-block, testimonials, gallery, location, faq, cta-banner

export default function HomePage() {
  return (
    <article className="pg-page">
      {/* H1 direction: by Nanis`s Smashburger — Understand what this business offers and whether it fits the */}
      <nav aria-label="Interne Links">
        <ul>
          <li><a href="/menu">Speisekarte</a></li>
          <li><a href="/about">Über uns</a></li>
          <li><a href="/gallery">Galerie</a></li>
          <li><a href="/contact">Kontakt</a></li>
        </ul>
      </nav>
      <HeroSection
        section={page_startseiteConfig.sections[0]}
      />
      <TrustSection
        section={page_startseiteConfig.sections[1]}
      />
      <MenuSection
        section={page_startseiteConfig.sections[2]}
      />
      <TrustSection
        section={page_startseiteConfig.sections[3]}
      />
      <TestimonialSection
        section={page_startseiteConfig.sections[4]}
      />
      <GallerySection
        section={page_startseiteConfig.sections[5]}
      />
      <ContactSection
        section={page_startseiteConfig.sections[6]}
      />
      <FAQSection
        section={page_startseiteConfig.sections[7]}
      />
      <CTASection
        section={page_startseiteConfig.sections[8]}
      />
    </article>
  );
}
