/**
 * GENERATED PAGE — Kontakt
 * Route: /contact
 * Sprint 8.2B/8.2C — page-level React
 */

import type { Metadata } from 'next';
import { page_kontaktConfig } from '@/content/pages/page-kontakt';
import {
  CTASection,
  ContactSection,
  FeatureGridSection,
  HeroSection,
  LocationSection,
} from '@/components/generated';

export const metadata: Metadata = {
  // missing SEO inputs: location
  title: "Kontakt | by Nanis`s Smashburger",
  description: "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  robots: "index,follow",
  openGraph: {
    title: "by Nanis`s Smashburger — Kontakt",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "by Nanis`s Smashburger — Kontakt",
    description: "Mehr Kunden gewinnen und online bestellungen ermöglichen",
  },
  alternates: {
    canonical: "/contact",
  },
};

// selected patterns: hero, navbar, footer, location, feature-grid, cta-banner

export default function KontaktPage() {
  return (
    <article className="pg-page">
      {/* page objective rendered via sections for Kontakt */}
      <nav aria-label="Interne Links">
        <ul>
          <li><a href="/">Startseite</a></li>
          <li><a href="/menu">Speisekarte</a></li>
          <li><a href="/about">Über uns</a></li>
          <li><a href="/gallery">Galerie</a></li>
        </ul>
      </nav>
      <HeroSection
        section={page_kontaktConfig.sections[0]}
      />
      <ContactSection
        section={page_kontaktConfig.sections[1]}
      />
      <FeatureGridSection
        section={page_kontaktConfig.sections[2]}
      />
      <FeatureGridSection
        section={page_kontaktConfig.sections[3]}
      />
      <ContactSection
        section={page_kontaktConfig.sections[4]}
      />
      <LocationSection
        section={page_kontaktConfig.sections[5]}
      />
      <LocationSection
        section={page_kontaktConfig.sections[6]}
      />
      <CTASection
        section={page_kontaktConfig.sections[7]}
      />
    </article>
  );
}
