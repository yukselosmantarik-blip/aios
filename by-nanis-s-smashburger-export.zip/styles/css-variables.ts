/**
 * GENERATED CSS VARIABLE MAP — Sprint 8.2D
 */

export const cssVariables = {
  "--color-primary": "#111111",
  "--color-secondary": "#F59E0B",
  "--color-accent": "#F59E0B",
  "--color-background": "#FFFFFF",
  "--color-surface": "#FAFAFA",
  "--color-text": "#111827",
  "--color-text-primary": "#111827",
  "--color-muted": "#6B7280",
  "--color-text-muted": "#6B7280",
  "--color-border": "#E5E7EB",
  "--color-error": "#DC2626",
  "--font-heading": "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  "--font-body": "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  "--font-size-xs": "0.75rem",
  "--font-size-sm": "0.875rem",
  "--font-size-md": "1rem",
  "--font-size-lg": "1.125rem",
  "--font-size-xl": "1.25rem",
  "--font-size-2xl": "clamp(1.5rem, 2.5vw, 2rem)",
  "--font-size-display": "clamp(2.25rem, 4vw, 3rem)",
  "--font-weight-regular": "400",
  "--font-weight-medium": "500",
  "--font-weight-semibold": "600",
  "--font-weight-bold": "700",
  "--line-height-tight": "1.2",
  "--line-height-snug": "1.35",
  "--line-height-normal": "1.5",
  "--line-height-relaxed": "1.65",
  "--spacing-xs": "0.75rem",
  "--spacing-sm": "1rem",
  "--spacing-md": "1.5rem",
  "--spacing-lg": "5rem",
  "--spacing-xl": "4rem",
  "--spacing-2xl": "6rem",
  "--radius-sm": "0.375rem",
  "--radius-md": "0.75rem",
  "--radius-lg": "1rem",
  "--radius-pill": "9999px",
  "--shadow-sm": "0 1px 2px rgba(0,0,0,0.05)",
  "--shadow-md": "0 4px 12px rgba(0,0,0,0.08)",
  "--shadow-lg": "0 12px 32px rgba(0,0,0,0.12)",
  "--shadow-xl": "0 20px 40px rgba(0,0,0,0.14)",
  "--container-mobile": "100%",
  "--container-tablet": "65ch",
  "--container-desktop": "80rem",
  "--breakpoint-mobile": "640px",
  "--breakpoint-tablet": "768px",
  "--breakpoint-desktop": "1024px",
  "--z-index-header": "40",
  "--z-index-sticky": "30",
  "--z-index-modal": "50",
  "--dark-color-background": "#0B0B0B",
  "--dark-color-surface": "#141414",
  "--dark-color-text": "#F5F5F5",
  "--dark-color-muted": "#A3A3A3",
} as const;

export type CssVariables = typeof cssVariables;

export function cssVariableBlock(selector = ':root'): string {
  const lines = Object.entries(cssVariables).map(
    ([name, value]) => `  ${name}: ${value};`,
  );
  return `${selector} {\n${lines.join('\n')}\n}`;
}
