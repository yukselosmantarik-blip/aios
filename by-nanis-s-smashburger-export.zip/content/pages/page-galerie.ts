/**
 * GENERATED PAGE CONFIG — Sprint 8.2B
 * Page: Galerie
 */

export const page_galerieConfig = {
  "pageId": "page:galerie",
  "pageName": "Galerie",
  "pageRole": "gallery",
  "title": "Galerie | by Nanis`s Smashburger",
  "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  "route": "/gallery",
  "h1Direction": "by Nanis`s Smashburger — See real photos of products, venue, or results.",
  "primaryCta": "Jetzt bestellen",
  "secondaryCta": "Standort & Öffnungszeiten",
  "selectedPatternIds": [
    "hero",
    "navbar",
    "footer",
    "feature-grid",
    "gallery",
    "cta-banner"
  ],
  "sections": [
    {
      "id": "section:galerie-hero",
      "title": "by Nanis`s Smashburger",
      "name": "HeroSection",
      "eyebrow": "100 % Halal",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "hero",
      "order": 1,
      "priority": 100,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Provide visual proof of quality.",
      "componentName": "HeroSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [],
      "primaryCTA": "Jetzt bestellen",
      "secondaryCTA": "Standort & Öffnungszeiten",
      "media": [],
      "ctaReferences": [
        "Jetzt bestellen",
        "Standort & Öffnungszeiten"
      ],
      "mediaReferences": [],
      "headingLevel": 1,
      "sourcePatternIds": [
        "hero"
      ],
      "contentBody": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": []
    },
    {
      "id": "section:galerie-galleryfilterbar",
      "title": "Galerie",
      "name": "GalleryFilterBar",
      "eyebrow": null,
      "description": ".",
      "type": "feature-grid",
      "order": 2,
      "priority": 68,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Optional category filtering for gallery images.",
      "componentName": "FeatureGridSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: categories — e.g. Food, Interior, Events"
      ],
      "contentBlocks": [
        "content-block:page-galerie-galleryfilterbar"
      ],
      "contentBody": ".",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "feature-grid"
      ]
    },
    {
      "id": "section:galerie-gallerygrid",
      "title": "Galerie",
      "name": "GalleryGrid",
      "eyebrow": null,
      "description": "6–12 images .",
      "type": "gallery",
      "order": 3,
      "priority": 65,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Display visual portfolio of the business.",
      "componentName": "GallerySection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: client gallery assets"
      ],
      "contentBlocks": [
        "content-block:page-galerie-gallerygrid"
      ],
      "contentBody": "6–12 images .",
      "contentLines": [
        "6–12 images ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "gallery"
      ]
    },
    {
      "id": "section:galerie-lightboxviewer",
      "title": "Galerie",
      "name": "LightboxViewer",
      "eyebrow": null,
      "description": "Full-resolution image ; caption .",
      "type": "gallery",
      "order": 4,
      "priority": 62,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Fullscreen image inspection.",
      "componentName": "GallerySection",
      "isPlaceholder": true,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-galerie-lightboxviewer"
      ],
      "contentBody": "Full-resolution image ; caption .",
      "contentLines": [
        "Full-resolution image",
        "caption ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "gallery"
      ]
    },
    {
      "id": "section:galerie-galleryloadingskeleton",
      "title": "Galerie",
      "name": "GalleryLoadingSkeleton",
      "eyebrow": null,
      "description": "Skeleton placeholders matching grid cell count.",
      "type": "gallery",
      "order": 5,
      "priority": 58,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Perceived performance while images load.",
      "componentName": "GallerySection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-galerie-galleryloadingskeleton"
      ],
      "contentBody": "Skeleton placeholders matching grid cell count.",
      "contentLines": [
        "Skeleton placeholders matching grid cell count."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "gallery"
      ]
    },
    {
      "id": "section:galerie-instagramteaser",
      "title": "Galerie",
      "name": "InstagramTeaser",
      "eyebrow": null,
      "description": "— embed or link-out only; no invented feed content.",
      "type": "gallery",
      "order": 6,
      "priority": 55,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Social gallery integration behavior.",
      "componentName": "GallerySection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: Instagram handle from client"
      ],
      "contentBlocks": [
        "content-block:page-galerie-instagramteaser"
      ],
      "contentBody": "— embed or link-out only; no invented feed content.",
      "contentLines": [
        "— embed or link-out only",
        "no invented feed content."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "gallery"
      ]
    },
    {
      "id": "section:galerie-galleryfinalcta",
      "title": "Galerie",
      "name": "GalleryFinalCTA",
      "eyebrow": null,
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "cta-banner",
      "order": 7,
      "priority": 71,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Convert visual interest into visit or order.",
      "componentName": "GallerySection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-galerie-galleryfinalcta"
      ],
      "contentBody": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "contentLines": [
        "Mehr Kunden gewinnen und online bestellungen ermöglichen"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "cta-banner"
      ]
    }
  ],
  "ctas": {
    "primary": "Jetzt bestellen",
    "secondary": "Standort & Öffnungszeiten"
  },
  "mediaPlaceholders": [
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]"
  ],
  "seo": {
    "title": "Galerie | by Nanis`s Smashburger",
    "titlePattern": "{page} | {businessName}",
    "metaDescription": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
    "canonical": "/gallery",
    "robots": "index,follow",
    "openGraph": {
      "title": "by Nanis`s Smashburger — Galerie",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "website"
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "by Nanis`s Smashburger — Galerie",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen"
    },
    "primaryKeyword": "Smashburger",
    "supportingKeywords": [
      "Smashburger",
      "Hot Dogs",
      "Pommes",
      "Desserts",
      "Smashburger Restaurant"
    ],
    "h1Direction": "by Nanis`s Smashburger — See real photos of products, venue, or results.",
    "structuredDataType": "WebPage",
    "breadcrumbRecommendation": [
      "Home",
      "Galerie"
    ],
    "internalLinks": [
      "/",
      "/menu",
      "/about",
      "/contact"
    ],
    "missingSeoInputs": [
      "location"
    ]
  },
  "missingDataReferences": [
    "address",
    "phone",
    "email",
    "opening hours",
    "testimonials",
    "legal text",
    "domain",
    "product prices"
  ],
  "internalLinks": [
    "/",
    "/menu",
    "/about",
    "/contact"
  ],
  "implementationWarnings": []
} as const;

export type page_galerieConfigType = typeof page_galerieConfig;
