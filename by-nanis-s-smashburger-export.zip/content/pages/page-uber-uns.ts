/**
 * GENERATED PAGE CONFIG — Sprint 8.2B
 * Page: Über uns
 */

export const page_uber_unsConfig = {
  "pageId": "page:uber-uns",
  "pageName": "Über uns",
  "pageRole": "about",
  "title": "Über uns | by Nanis`s Smashburger",
  "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  "route": "/about",
  "h1Direction": "by Nanis`s Smashburger — Learn brand story, values, and credibility.",
  "primaryCta": "Jetzt bestellen",
  "secondaryCta": "Standort & Öffnungszeiten",
  "selectedPatternIds": [
    "hero",
    "navbar",
    "footer",
    "timeline",
    "feature-grid",
    "usp-block",
    "team",
    "statistics",
    "cta-banner"
  ],
  "sections": [
    {
      "id": "section:uber-uns-hero",
      "title": "by Nanis`s Smashburger",
      "name": "HeroSection",
      "eyebrow": "100 % Halal",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "hero",
      "order": 1,
      "priority": 100,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Build brand trust and emotional connection.",
      "componentName": "HeroSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [],
      "primaryCTA": "Jetzt bestellen",
      "secondaryCTA": "Standort & Öffnungszeiten",
      "media": [],
      "ctaReferences": [
        "Jetzt bestellen",
        "Standort & Öffnungszeiten"
      ],
      "mediaReferences": [],
      "headingLevel": 1,
      "sourcePatternIds": [
        "hero"
      ],
      "contentBody": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": []
    },
    {
      "id": "section:uber-uns-brandstory",
      "title": "Unsere Geschichte",
      "name": "BrandStory",
      "eyebrow": null,
      "description": "by Nanis`s Smashburger in Smashburger Restaurant; story .",
      "type": "timeline",
      "order": 2,
      "priority": 82,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Tell the origin and context of the business.",
      "componentName": "ContentSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: client narrative"
      ],
      "contentBlocks": [
        "content-block:page-uber-uns-brandstory"
      ],
      "contentBody": "by Nanis`s Smashburger in Smashburger Restaurant; story .",
      "contentLines": [
        "by Nanis`s Smashburger in Smashburger Restaurant",
        "story ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "timeline"
      ]
    },
    {
      "id": "section:uber-uns-missionvalues",
      "title": "Mission & Werte",
      "name": "MissionValues",
      "eyebrow": null,
      "description": "Mission tied to: Mehr Kunden gewinnen und online bestellungen ermöglichen; values from USP.",
      "type": "feature-grid",
      "order": 3,
      "priority": 64,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Communicate mission aligned with website goal.",
      "componentName": "FeatureGridSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-uber-uns-missionvalues"
      ],
      "contentBody": "Mission tied to: Mehr Kunden gewinnen und online bestellungen ermöglichen; values from USP.",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "feature-grid"
      ]
    },
    {
      "id": "section:uber-uns-qualitypromise",
      "title": "Über uns",
      "name": "QualityPromise",
      "eyebrow": null,
      "description": "100 % Halal, frische Zutaten",
      "type": "usp-block",
      "order": 4,
      "priority": 71,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Reinforce quality claims from brief USP.",
      "componentName": "TrustSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-uber-uns-qualitypromise"
      ],
      "contentBody": "100 % Halal, frische Zutaten",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "usp-block"
      ]
    },
    {
      "id": "section:uber-uns-teamfounder",
      "title": "Über uns",
      "name": "TeamFounder",
      "eyebrow": null,
      "description": ", , , .",
      "type": "team",
      "order": 5,
      "priority": 57,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Humanize the brand with team or founder placeholder.",
      "componentName": "GenericSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: founder name",
        "PLACEHOLDER: role",
        "PLACEHOLDER: bio",
        "PLACEHOLDER: photo"
      ],
      "contentBlocks": [
        "content-block:page-uber-uns-teamfounder"
      ],
      "contentBody": ", , , .",
      "contentLines": [
        ", , , ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "team"
      ]
    },
    {
      "id": "section:uber-uns-trustelements",
      "title": "Über uns",
      "name": "TrustElements",
      "eyebrow": null,
      "description": "USP badges, Smashburger Restaurant trust markers .",
      "type": "statistics",
      "order": 6,
      "priority": 64,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Credibility signals from brief only.",
      "componentName": "TrustSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: certifications if any"
      ],
      "contentBlocks": [
        "content-block:page-uber-uns-trustelements"
      ],
      "contentBody": "USP badges, Smashburger Restaurant trust markers .",
      "contentLines": [
        "USP badges, Smashburger Restaurant trust markers ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "statistics"
      ]
    },
    {
      "id": "section:uber-uns-finalcta",
      "title": "by Nanis`s Smashburger",
      "name": "FinalCTA",
      "eyebrow": null,
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "cta-banner",
      "order": 7,
      "priority": 81,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Convert informed visitors.",
      "componentName": "CTASection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-uber-uns-finalcta"
      ],
      "contentBody": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "contentLines": [
        "Mehr Kunden gewinnen und online bestellungen ermöglichen"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "cta-banner"
      ]
    }
  ],
  "ctas": {
    "primary": "Jetzt bestellen",
    "secondary": "Standort & Öffnungszeiten"
  },
  "mediaPlaceholders": [
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]"
  ],
  "seo": {
    "title": "Über uns | by Nanis`s Smashburger",
    "titlePattern": "{page} | {businessName}",
    "metaDescription": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
    "canonical": "/about",
    "robots": "index,follow",
    "openGraph": {
      "title": "by Nanis`s Smashburger — Über uns",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "website"
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "by Nanis`s Smashburger — Über uns",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen"
    },
    "primaryKeyword": "Smashburger",
    "supportingKeywords": [
      "Smashburger",
      "Hot Dogs",
      "Pommes",
      "Desserts",
      "Smashburger Restaurant"
    ],
    "h1Direction": "by Nanis`s Smashburger — Learn brand story, values, and credibility.",
    "structuredDataType": "WebPage",
    "breadcrumbRecommendation": [
      "Home",
      "Über uns"
    ],
    "internalLinks": [
      "/",
      "/menu",
      "/gallery",
      "/contact"
    ],
    "missingSeoInputs": [
      "location"
    ]
  },
  "missingDataReferences": [
    "address",
    "phone",
    "email",
    "opening hours",
    "testimonials",
    "legal text",
    "domain",
    "product prices"
  ],
  "internalLinks": [
    "/",
    "/menu",
    "/gallery",
    "/contact"
  ],
  "implementationWarnings": []
} as const;

export type page_uber_unsConfigType = typeof page_uber_unsConfig;
