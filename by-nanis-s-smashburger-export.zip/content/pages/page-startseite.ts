/**
 * GENERATED PAGE CONFIG — Sprint 8.2B
 * Page: Startseite
 */

export const page_startseiteConfig = {
  "pageId": "page:startseite",
  "pageName": "Startseite",
  "pageRole": "home",
  "title": "Startseite | by Nanis`s Smashburger",
  "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  "route": "/",
  "h1Direction": "by Nanis`s Smashburger — Understand what this business offers and whether it fits the",
  "primaryCta": "Jetzt bestellen",
  "secondaryCta": "Standort & Öffnungszeiten",
  "selectedPatternIds": [
    "hero",
    "navbar",
    "footer",
    "statistics",
    "menu-grid",
    "usp-block",
    "testimonials",
    "gallery",
    "location",
    "faq",
    "cta-banner"
  ],
  "sections": [
    {
      "id": "home",
      "title": "by Nanis`s Smashburger",
      "name": "HeroSection",
      "eyebrow": "100 % Halal",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "hero",
      "order": 1,
      "priority": 100,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Drive Burger liebhaber, familien, studenten toward Mehr Kunden gewinnen und online bestellungen ermöglichen. Prioritize menu visibility and order path.",
      "componentName": "HeroSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [],
      "primaryCTA": "Jetzt bestellen",
      "secondaryCTA": "Standort & Öffnungszeiten",
      "media": [],
      "ctaReferences": [
        "#menu",
        "#contact"
      ],
      "mediaReferences": [],
      "headingLevel": 1,
      "sourcePatternIds": [
        "hero"
      ],
      "contentBody": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "heroLayout": "premium-restaurant",
      "tagline": "100 % Halal",
      "primaryCtaHref": "#menu",
      "secondaryCtaHref": "#contact",
      "phone": "0162 2083583",
      "address": "Klosterstraße 21, 89143 Blaubeuren",
      "className": "hero-premium"
    },
    {
      "id": "menu",
      "title": "Unsere Speisekarte",
      "name": "MenuImageSection",
      "eyebrow": null,
      "description": "Alle Gerichte, Preise und Specials — übersichtlich als Speisekarte zum Ansehen.",
      "type": "menu-grid",
      "order": 2,
      "priority": 90,
      "hierarchyLevel": "primary",
      "visualWeight": "high",
      "purpose": "Present the full menu image",
      "componentName": "MenuImageSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "menu-grid"
      ],
      "contentBody": "",
      "contentLines": [],
      "trustBadges": [],
      "menuItems": [],
      "faqItems": []
    },
    {
      "id": "contact",
      "title": "Kontakt & Öffnungszeiten",
      "name": "BusinessInfoSection",
      "eyebrow": null,
      "description": "Besuchen Sie uns in Blaubeuren oder rufen Sie uns an.",
      "type": "contact-details",
      "order": 3,
      "priority": 85,
      "hierarchyLevel": "primary",
      "visualWeight": "high",
      "purpose": "Business contact and opening hours",
      "componentName": "BusinessInfoSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "location"
      ],
      "contentBody": "",
      "contentLines": [],
      "trustBadges": [],
      "menuItems": [],
      "faqItems": []
    }
  ],
  "ctas": {
    "primary": "Jetzt bestellen",
    "secondary": "Standort & Öffnungszeiten"
  },
  "mediaPlaceholders": [
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]"
  ],
  "seo": {
    "title": "Startseite | by Nanis`s Smashburger",
    "titlePattern": "{page} | {businessName}",
    "metaDescription": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
    "canonical": "/",
    "robots": "index,follow",
    "openGraph": {
      "title": "by Nanis`s Smashburger — Startseite",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "website"
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "by Nanis`s Smashburger — Startseite",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen"
    },
    "primaryKeyword": "Smashburger",
    "supportingKeywords": [
      "Smashburger",
      "Hot Dogs",
      "Pommes",
      "Desserts",
      "Smashburger Restaurant"
    ],
    "h1Direction": "by Nanis`s Smashburger — Understand what this business offers and whether it fits the",
    "structuredDataType": "Organization",
    "breadcrumbRecommendation": [
      "Home",
      "Startseite"
    ],
    "internalLinks": [
      "/menu",
      "/about",
      "/gallery",
      "/contact"
    ],
    "missingSeoInputs": [
      "location"
    ]
  },
  "missingDataReferences": [
    "address",
    "phone",
    "email",
    "opening hours",
    "testimonials",
    "legal text",
    "domain",
    "product prices"
  ],
  "internalLinks": [
    "/menu",
    "/about",
    "/gallery",
    "/contact"
  ],
  "implementationWarnings": [
    "high: Too many high-emphasis sections marked dominant."
  ]
} as const;

export type page_startseiteConfigType = typeof page_startseiteConfig;
