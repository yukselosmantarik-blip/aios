/**
 * GENERATED PAGE CONFIG — Sprint 8.2B
 * Page: Startseite
 */

export const page_startseiteConfig = {
  "pageId": "page:startseite",
  "pageName": "Startseite",
  "pageRole": "home",
  "title": "Startseite | by Nanis`s Smashburger",
  "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
  "route": "/",
  "h1Direction": "by Nanis`s Smashburger — Understand what this business offers and whether it fits the",
  "primaryCta": "Jetzt bestellen",
  "secondaryCta": "Standort & Öffnungszeiten",
  "selectedPatternIds": [
    "hero",
    "navbar",
    "footer",
    "statistics",
    "menu-grid",
    "usp-block",
    "testimonials",
    "gallery",
    "location",
    "faq",
    "cta-banner"
  ],
  "sections": [
    {
      "id": "section:startseite-hero",
      "title": "by Nanis`s Smashburger",
      "name": "HeroSection",
      "eyebrow": "100 % Halal",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "hero",
      "order": 1,
      "priority": 100,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Drive Burger liebhaber, familien, studenten toward Mehr Kunden gewinnen und online bestellungen ermöglichen. Prioritize menu visibility and order path.",
      "componentName": "HeroSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [],
      "primaryCTA": "Jetzt bestellen",
      "secondaryCTA": "Standort & Öffnungszeiten",
      "media": [],
      "ctaReferences": [
        "Jetzt bestellen",
        "Standort & Öffnungszeiten"
      ],
      "mediaReferences": [],
      "headingLevel": 1,
      "sourcePatternIds": [
        "hero"
      ],
      "contentBody": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": []
    },
    {
      "id": "section:startseite-trustbar",
      "title": "100 % Halal, frische Zutaten",
      "name": "TrustBar",
      "eyebrow": null,
      "description": "3–4 badges derived from brief USP: 100 % Halal, frische Zutaten",
      "type": "statistics",
      "order": 2,
      "priority": 92,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Establish immediate credibility before scroll.",
      "componentName": "TrustSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-startseite-trustbar"
      ],
      "contentBody": "3–4 badges derived from brief USP: 100 % Halal, frische Zutaten",
      "contentLines": [
        "3–4 badges derived from brief USP: 100 % Halal, frische Zutaten"
      ],
      "trustBadges": [
        "3–4 badges derived from brief USP: 100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "statistics"
      ]
    },
    {
      "id": "section:startseite-featureditems",
      "title": "Beliebte Speisen",
      "name": "FeaturedItems",
      "eyebrow": null,
      "description": "Feature top items: Smashburger, Hot Dogs, Pommes with and .",
      "type": "menu-grid",
      "order": 3,
      "priority": 91,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Highlight bestsellers or core services from brief.",
      "componentName": "MenuSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: description",
        "PLACEHOLDER: price"
      ],
      "contentBlocks": [
        "content-block:page-startseite-featureditems"
      ],
      "contentBody": "Feature top items: Smashburger, Hot Dogs, Pommes with and .",
      "contentLines": [
        "Feature top items: Smashburger, Hot Dogs, Pommes with and ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [
        {
          "id": "menu-item-1",
          "name": "Smashburger",
          "category": "Highlights",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-2",
          "name": "Hot Dogs",
          "category": "Highlights",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-3",
          "name": "Pommes",
          "category": "Highlights",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-4",
          "name": "Desserts",
          "category": "Klassiker",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-5",
          "name": "Kaffee",
          "category": "Klassiker",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-6",
          "name": "Cocktails",
          "category": "Klassiker",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-7",
          "name": "Getränke",
          "category": "Klassiker",
          "description": "100 % Halal, frische Zutaten"
        },
        {
          "id": "menu-item-8",
          "name": "Take-Away",
          "category": "Klassiker",
          "description": "100 % Halal, frische Zutaten"
        }
      ],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "menu-grid"
      ]
    },
    {
      "id": "section:startseite-uspgrid",
      "title": "Was uns auszeichnet",
      "name": "USPGrid",
      "eyebrow": "usp-block",
      "description": "100 % Halal, frische Zutaten",
      "type": "usp-block",
      "order": 4,
      "priority": 83,
      "hierarchyLevel": "primary",
      "visualWeight": "high",
      "purpose": "Expand on unique selling proposition from brief.",
      "componentName": "TrustSection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-startseite-uspgrid"
      ],
      "contentBody": "100 % Halal, frische Zutaten",
      "contentLines": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "usp-block"
      ]
    },
    {
      "id": "section:startseite-testimonialsection",
      "title": "Stimmen unserer Gäste",
      "name": "TestimonialSection",
      "eyebrow": null,
      "description": "3 testimonial placeholders: , , .",
      "type": "testimonials",
      "order": 5,
      "priority": 37,
      "hierarchyLevel": "supporting",
      "visualWeight": "low",
      "purpose": "Social proof for target audience.",
      "componentName": "TestimonialSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: quote",
        "PLACEHOLDER: name",
        "PLACEHOLDER: context"
      ],
      "contentBlocks": [
        "content-block:page-startseite-testimonialsection"
      ],
      "contentBody": "3 testimonial placeholders: , , .",
      "contentLines": [
        "3 testimonial placeholders: , , ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 3,
      "sourcePatternIds": [
        "testimonials"
      ]
    },
    {
      "id": "section:startseite-galleryteaser",
      "title": "Einblicke",
      "name": "GalleryTeaser",
      "eyebrow": null,
      "description": "4–6 teaser images .",
      "type": "gallery",
      "order": 6,
      "priority": 65,
      "hierarchyLevel": "secondary",
      "visualWeight": "medium",
      "purpose": "Visual proof of quality and atmosphere.",
      "componentName": "GallerySection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: client gallery assets"
      ],
      "contentBlocks": [
        "content-block:page-startseite-galleryteaser"
      ],
      "contentBody": "4–6 teaser images .",
      "contentLines": [
        "4–6 teaser images ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 2,
      "sourcePatternIds": [
        "gallery"
      ]
    },
    {
      "id": "section:startseite-locationcontactteaser",
      "title": "Besuchen Sie uns",
      "name": "LocationContactTeaser",
      "eyebrow": null,
      "description": ", , .",
      "type": "location",
      "order": 7,
      "priority": 26,
      "hierarchyLevel": "utility",
      "visualWeight": "minimal",
      "purpose": "Reduce friction for visit or inquiry.",
      "componentName": "ContactSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: address",
        "PLACEHOLDER: hours",
        "PLACEHOLDER: contact"
      ],
      "contentBlocks": [
        "content-block:page-startseite-locationcontactteaser"
      ],
      "contentBody": ", , .",
      "contentLines": [
        ", , ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 3,
      "sourcePatternIds": [
        "location"
      ]
    },
    {
      "id": "section:startseite-faqsection",
      "title": "Häufige Fragen",
      "name": "FAQSection",
      "eyebrow": null,
      "description": "FAQ: Suitable for Burger liebhaber, familien, studenten? → Yes, per brief positioning. | FAQ: How to contact by Nanis`s Smashburger? → Kontakt. | FAQ: Can I order online? → Align with brief goal: Mehr Kunden gewinnen und online bestellungen",
      "type": "faq",
      "order": 8,
      "priority": 53,
      "hierarchyLevel": "supporting",
      "visualWeight": "low",
      "purpose": "Handle common objections before conversion.",
      "componentName": "FAQSection",
      "isPlaceholder": true,
      "missingData": [
        "PLACEHOLDER: confirm from brief USP/services",
        "PLACEHOLDER: hours on contact/location page"
      ],
      "contentBlocks": [
        "content-block:page-startseite-faqsection"
      ],
      "contentBody": "FAQ: Suitable for Burger liebhaber, familien, studenten? → Yes, per brief positioning. | FAQ: How to contact by Nanis`s Smashburger? → Kontakt. | FAQ: Can I order online? → Align with brief goal: Mehr Kunden gewinnen und online bestellungen ermöglichen. | FAQ: Dietary options? → . | FAQ: Opening hours? → .",
      "contentLines": [
        "FAQ: Suitable for Burger liebhaber, familien, studenten? → Yes, per brief positioning.",
        "FAQ: How to contact by Nanis`s Smashburger? → Kontakt.",
        "FAQ: Can I order online? → Align with brief goal: Mehr Kunden gewinnen und online bestellungen ermöglichen.",
        "FAQ: Dietary options? → .",
        "FAQ: Opening hours? → ."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [
        {
          "id": "section:startseite-faqsection-faq-1",
          "question": "Suitable for Burger liebhaber, familien, studenten?",
          "answer": "Yes, per brief positioning."
        },
        {
          "id": "section:startseite-faqsection-faq-2",
          "question": "How to contact by Nanis`s Smashburger?",
          "answer": "Kontakt."
        },
        {
          "id": "section:startseite-faqsection-faq-3",
          "question": "Can I order online?",
          "answer": "Align with brief goal: Mehr Kunden gewinnen und online bestellungen ermöglichen."
        },
        {
          "id": "section:startseite-faqsection-faq-4",
          "question": "Dietary options?",
          "answer": "."
        },
        {
          "id": "section:startseite-faqsection-faq-5",
          "question": "Opening hours?",
          "answer": "."
        }
      ],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [
        "[PLACEHOLDER: media asset]"
      ],
      "ctaReferences": [],
      "mediaReferences": [
        "[PLACEHOLDER: media asset]"
      ],
      "headingLevel": 3,
      "sourcePatternIds": [
        "faq"
      ]
    },
    {
      "id": "section:startseite-finalcta",
      "title": "by Nanis`s Smashburger",
      "name": "FinalCTA",
      "eyebrow": null,
      "description": "Restate goal: Mehr Kunden gewinnen und online bestellungen ermöglichen.",
      "type": "cta-banner",
      "order": 9,
      "priority": 83,
      "hierarchyLevel": "dominant",
      "visualWeight": "very-high",
      "purpose": "Final conversion push before footer.",
      "componentName": "CTASection",
      "isPlaceholder": false,
      "missingData": [],
      "contentBlocks": [
        "content-block:page-startseite-finalcta"
      ],
      "contentBody": "Restate goal: Mehr Kunden gewinnen und online bestellungen ermöglichen.",
      "contentLines": [
        "Restate goal: Mehr Kunden gewinnen und online bestellungen ermöglichen."
      ],
      "trustBadges": [
        "100 % Halal",
        "frische Zutaten"
      ],
      "menuItems": [],
      "faqItems": [],
      "primaryCTA": null,
      "secondaryCTA": null,
      "media": [],
      "ctaReferences": [],
      "mediaReferences": [],
      "headingLevel": 2,
      "sourcePatternIds": [
        "cta-banner"
      ]
    }
  ],
  "ctas": {
    "primary": "Jetzt bestellen",
    "secondary": "Standort & Öffnungszeiten"
  },
  "mediaPlaceholders": [
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]",
    "[PLACEHOLDER: media asset]"
  ],
  "seo": {
    "title": "Startseite | by Nanis`s Smashburger",
    "titlePattern": "{page} | {businessName}",
    "metaDescription": "Mehr Kunden gewinnen und online bestellungen ermöglichen — Burger liebhaber, familien, studenten",
    "canonical": "/",
    "robots": "index,follow",
    "openGraph": {
      "title": "by Nanis`s Smashburger — Startseite",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen",
      "type": "website"
    },
    "twitter": {
      "card": "summary_large_image",
      "title": "by Nanis`s Smashburger — Startseite",
      "description": "Mehr Kunden gewinnen und online bestellungen ermöglichen"
    },
    "primaryKeyword": "Smashburger",
    "supportingKeywords": [
      "Smashburger",
      "Hot Dogs",
      "Pommes",
      "Desserts",
      "Smashburger Restaurant"
    ],
    "h1Direction": "by Nanis`s Smashburger — Understand what this business offers and whether it fits the",
    "structuredDataType": "Organization",
    "breadcrumbRecommendation": [
      "Home",
      "Startseite"
    ],
    "internalLinks": [
      "/menu",
      "/about",
      "/gallery",
      "/contact"
    ],
    "missingSeoInputs": [
      "location"
    ]
  },
  "missingDataReferences": [
    "address",
    "phone",
    "email",
    "opening hours",
    "testimonials",
    "legal text",
    "domain",
    "product prices"
  ],
  "internalLinks": [
    "/menu",
    "/about",
    "/gallery",
    "/contact"
  ],
  "implementationWarnings": [
    "high: Too many high-emphasis sections marked dominant."
  ]
} as const;

export type page_startseiteConfigType = typeof page_startseiteConfig;
