/**
 * GENERATED COMPONENT — FAQSection
 * Sprint 8.3 — premium visual component library
 */

'use client';


import type { SectionComponentProps } from './types';
import { SectionHeading } from './SectionHeading';
import { SectionShell } from './SectionShell';
import { Container } from './Container';
import { Stack } from './Stack';
import { cn, variants } from '@/styles/tailwind-mapping';
import { ButtonLink } from './ButtonLink';

export function FAQSection({ section }: SectionComponentProps) {
  return (
    <SectionShell id={section.id} headingId={`${section.id}-heading`} className={section.className}>
      <Container>
        <Stack gap="lg">
          <SectionHeading section={section} />
          {(() => {
            const items = section.contentBlocks.length > 0
              ? section.contentBlocks.map((block, index) => ({
                  id: `${section.id}-faq-${index}`,
                  question: section.title,
                  answer: block,
                  isPlaceholder: section.isPlaceholder,
                }))
              : [{
                  id: `${section.id}-faq-1`,
                  question: section.title,
                  answer: "[PLACEHOLDER: FAQ answer]",
                  isPlaceholder: true,
                }];
            return (
              <Stack gap="sm">
                {items.map((item) => (
                  <details key={item.id} className={variants.faqDetails}>
                    <summary className="flex cursor-pointer list-none items-center justify-between gap-[var(--spacing-sm)] font-[var(--font-weight-medium)] focus-visible:outline-none [&::-webkit-details-marker]:hidden">
                      <span>{item.question}</span>
                      <span aria-hidden="true" className={cn("text-[var(--color-text-muted)] transition-transform", variants.motionSafe, "group-open:rotate-180")}>
                        ▾
                      </span>
                    </summary>
                    <p className="mt-[var(--spacing-sm)] text-[length:var(--font-size-sm)] text-[var(--color-text-muted)]">{item.answer}</p>
                  </details>
                ))}
              </Stack>
            );
          })()}
          {section.primaryCTA ? (
            <ButtonLink cta={{ label: section.primaryCTA, href: '/', variant: 'text' }} />
          ) : null}
        </Stack>
      </Container>
    </SectionShell>
  );
}
