/**
 * GENERATED COMPONENT — SiteFooter
 * Sprint 8.3 — premium visual component library
 */

import { cn, variants } from '@/styles/tailwind-mapping';
import Link from 'next/link';
import { ButtonLink } from './ButtonLink';
import { Cluster } from './Cluster';
import { Container } from './Container';
import { Placeholder } from './Placeholder';
import { Stack } from './Stack';

const footerVariant = "local-business" as const;

const footerGroups = [
    {
      title: "Seiten",
      items: [
          { label: "Startseite", href: "/" },
          { label: "Speisekarte", href: "/menu" },
          { label: "Über uns", href: "/about" },
          { label: "Galerie", href: "/gallery" },
          { label: "Kontakt", href: "/contact" },
      ],
    },
] as const;

const contactPlaceholders = [
  "[PLACEHOLDER: address]",
  "[PLACEHOLDER: phone]",
  "[PLACEHOLDER: email]",
] as const;

const legalPlaceholders = [
  "[PLACEHOLDER: Impressum]",
  "[PLACEHOLDER: Datenschutz]",
] as const;

const socialPlaceholders = [
  "[PLACEHOLDER: social profile URLs]",
] as const;

export function SiteFooter() {
  return (
    <footer className={cn(variants.footer, variants.motionSafe)} data-footer-variant={footerVariant}>
      <Container>
        <Stack gap="lg" className="py-[var(--spacing-xl)]">
          <div className="grid gap-[var(--spacing-lg)] md:grid-cols-2 lg:grid-cols-4">
            {footerGroups.map((group) => (
              <section key={group.title} aria-label={group.title}>
                <h2 className="mb-3 text-sm font-[var(--font-weight-semibold)] uppercase tracking-wide">
                  {group.title}
                </h2>
                <ul className="space-y-2">
                  {group.items.map((item) => (
                    <li key={item.href}>
                      <Link href={item.href} className="text-sm hover:underline">
                        {item.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
            <section aria-label="Kontakt">
              <h2 className="mb-3 text-sm font-[var(--font-weight-semibold)] uppercase tracking-wide">Kontakt</h2>
              <Cluster gap="sm">
                {contactPlaceholders.map((label) => (
                  <Placeholder key={label} label={label} category="phone" />
                ))}
              </Cluster>
            </section>
            <section aria-label="Rechtliches">
              <h2 className="mb-3 text-sm font-[var(--font-weight-semibold)] uppercase tracking-wide">Rechtliches</h2>
              <Cluster gap="sm">
                {legalPlaceholders.map((label) => (
                  <Placeholder key={label} label={label} category="legal" />
                ))}
              </Cluster>
            </section>
          </div>
          <div className={cn("border-t pt-[var(--spacing-md)]", variants.borderDefault)}>
            <div className="flex flex-col gap-[var(--spacing-md)] md:flex-row md:items-center md:justify-between">
              <Cluster gap="sm" aria-label="Social Links">
                {socialPlaceholders.map((label) => (
                  <Placeholder key={label} label={label} category="social-link" />
                ))}
              </Cluster>
              <ButtonLink
                cta={{
                  label: "Jetzt bestellen",
                  href: "/contact",
                  variant: 'secondary',
                }}
              />
            </div>
          </div>
        </Stack>
      </Container>
    </footer>
  );
}
