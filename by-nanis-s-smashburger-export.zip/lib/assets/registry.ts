/**
 * GENERATED ASSET REGISTRY — Sprint 8.4
 * Components must request assets through resolveAsset() only.
 */

export const assetRegistry = {
  logo: {
    id: "logo",
    path: "/icons/logo.svg",
    assetType: "logo",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Logo asset missing — LOGO REQUIRED",
    source: "placeholder",
  },
  favicon: {
    id: "favicon",
    path: "/icons/favicon.svg",
    assetType: "favicon",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Favicon asset missing",
    source: "placeholder",
  },
  hero: {
    id: "hero",
    path: "/images/hero-placeholder.svg",
    assetType: "hero",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Hero image missing — HERO IMAGE REQUIRED",
    source: "placeholder",
  },
  gallery: {
    id: "gallery",
    path: "/images/gallery-placeholder.svg",
    assetType: "gallery",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Gallery image missing — GALLERY IMAGE REQUIRED",
    source: "placeholder",
  },
  product: {
    id: "product",
    path: "/images/product-placeholder.svg",
    assetType: "product",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Product image missing — PRODUCT IMAGE REQUIRED",
    source: "placeholder",
  },
  map: {
    id: "map",
    path: "/images/map-placeholder.svg",
    assetType: "map",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Map asset missing",
    source: "placeholder",
  },
  avatar: {
    id: "avatar",
    path: "/images/avatar-placeholder.svg",
    assetType: "avatar",
    placeholder: true,
    replaceBeforeProduction: true,
    altText: "Avatar image missing",
    source: "placeholder",
  },
} as const;

export type AssetId = keyof typeof assetRegistry;

export type AssetType = (typeof assetRegistry)[AssetId]["assetType"];

export type AssetSource = (typeof assetRegistry)[AssetId]["source"];

export type ResolvedAsset = (typeof assetRegistry)[AssetId];
